function performAction(action) {
  alert(action + " PDF functionality will be processed via backend.");
}